﻿using System.ComponentModel.DataAnnotations;



namespace RaceDay.Api.DTOs;



/// <summary>

/// Contains the information required to create a RaceDay account.

/// </summary>

public class RegisterDto

{

    [Required, MaxLength(50)]

    public string Username { get; set; } = string.Empty;



    [Required, EmailAddress]

    public string Email { get; set; } = string.Empty;



    [Required, MinLength(8)]

    public string Password { get; set; } = string.Empty;



    [Required]

    public string Role { get; set; } = "Participant";



    [Required, MaxLength(50)]

    public string FirstName { get; set; } = string.Empty;



    [Required, MaxLength(50)]

    public string LastName { get; set; } = string.Empty;



    public DateOnly? DateOfBirth { get; set; }

}



/// <summary>

/// Contains credentials submitted when logging in.

/// </summary>

public class LoginDto

{

    [Required]

    public string Username { get; set; } = string.Empty;



    [Required]

    public string Password { get; set; } = string.Empty;

}
