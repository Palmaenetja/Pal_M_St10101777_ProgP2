﻿using System.ComponentModel.DataAnnotations;



namespace RaceDay.Api.DTOs;



/// <summary>

/// Contains the information required to enrol a participant

/// in an event category.

/// </summary>

public class EnrollmentCreateDto

{

    /// <summary>

    /// Gets or sets the event identifier.

    /// </summary>

    [Range(1, int.MaxValue)]

    public int EventId { get; set; }



    /// <summary>

    /// Gets or sets the category identifier.

    /// </summary>

    [Range(1, int.MaxValue)]

    public int CategoryId { get; set; }

}


