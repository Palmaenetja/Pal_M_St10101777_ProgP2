﻿using System.ComponentModel.DataAnnotations;



namespace RaceDay.Api.Models;



/// <summary>

/// Represents an age-group or distance category for an event.

/// </summary>

public class Category

{

    public int CategoryId { get; set; }



    public int EventId { get; set; }



    [Required, MaxLength(50)]

    public string Name { get; set; } = string.Empty;



    [MaxLength(255)]

    public string Description { get; set; } = string.Empty;



    public int? MinimumAge { get; set; }



    public int? MaximumAge { get; set; }



    public decimal? DistanceKm { get; set; }



    public Event Event { get; set; } = null!;



    public ICollection<Enrollment> Enrollments { get; set; }

        = new List<Enrollment>();

}



