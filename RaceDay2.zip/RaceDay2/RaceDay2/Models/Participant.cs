﻿using System.ComponentModel.DataAnnotations;



namespace RaceDay.Api.Models;

/// <summary>

/// Stores personal details belonging to a participant account.

/// </summary>

public class Participant

{

    public int ParticipantId { get; set; }



    public int UserId { get; set; }



    [Required, MaxLength(50)]

    public string FirstName { get; set; } = string.Empty;



    [Required, MaxLength(50)]

    public string LastName { get; set; } = string.Empty;



    public DateOnly DateOfBirth { get; set; }



    public User User { get; set; } = null!;



    public ICollection<Enrollment> Enrollments { get; set; }

        = new List<Enrollment>();



    public ICollection<Performance> Performances { get; set; }

        = new List<Performance>();

}



