﻿using System.ComponentModel.DataAnnotations;



namespace RaceDay.Api.Models;



/// <summary>

/// Represents a registered RaceDay account and its assigned role.

/// </summary>

public class User

{

    public int UserId { get; set; }



    [Required, MaxLength(50)]

    public string Username { get; set; } = string.Empty;



    [Required, MaxLength(255)]

    public string PasswordHash { get; set; } = string.Empty;



    [Required, EmailAddress, MaxLength(100)]

    public string Email { get; set; } = string.Empty;



    [Required, MaxLength(20)]

    public string Role { get; set; } = "Participant";



    public Participant? Participant { get; set; }



    public ICollection<Event> OrganisedEvents { get; set; }

        = new List<Event>();

}



