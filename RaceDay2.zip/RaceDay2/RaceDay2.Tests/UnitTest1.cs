﻿using Microsoft.AspNetCore.Mvc.Testing;

using Xunit;



namespace RaceDay.Tests;



/// <summary>

/// Tests authentication and access control for RaceDay.

/// </summary>

public class AuthenticationTests

    : IClassFixture<WebApplicationFactory<Program>>

{

    private readonly HttpClient _client;



    public AuthenticationTests(

        WebApplicationFactory<Program> factory)

    {

        _client = factory.CreateClient(

            new WebApplicationFactoryClientOptions

            {

                AllowAutoRedirect = false

            });

    }



    [Fact]

    public async Task ProtectedEndpoint_WithoutLogin_Returns401()

    {

        var response = await _client.GetAsync("/api/profile/me");



        Assert.Equal(

            System.Net.HttpStatusCode.Unauthorized,

            response.StatusCode);

    }

}
