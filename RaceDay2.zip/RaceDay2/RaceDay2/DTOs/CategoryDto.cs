﻿using System.ComponentModel.DataAnnotations;



namespace RaceDay.Api.DTOs;



/// <summary>

/// Represents the data required to create or update an event category.

/// </summary>

public class CategoryDto

{

    [Required]

    [MaxLength(50)]

    public string Name { get; set; } = string.Empty;



    [MaxLength(255)]

    public string Description { get; set; } = string.Empty;



    [Range(0, 120)]

    public int? MinimumAge { get; set; }



    [Range(0, 120)]

    public int? MaximumAge { get; set; }



    [Range(typeof(decimal), "0.01", "1000")]

    public decimal? DistanceKm { get; set; }

}


