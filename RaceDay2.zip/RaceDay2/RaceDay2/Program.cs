using System.Security.Claims;

using Microsoft.AspNetCore.Authentication.Cookies;

using Microsoft.AspNetCore.Identity;

using Microsoft.EntityFrameworkCore;

using Microsoft.OpenApi.Models;

using RaceDay.Api.Data;

using RaceDay.Api.Models;



var builder = WebApplication.CreateBuilder(args);



builder.Services.AddControllers();



builder.Services.AddDbContext<RaceDayDbContext>(options =>

    options.UseSqlServer(

        builder.Configuration.GetConnectionString("DefaultConnection")));



builder.Services.AddScoped<IPasswordHasher<User>,

    PasswordHasher<User>>();



builder.Services.AddDistributedMemoryCache();



builder.Services.AddSession(options =>

{

    options.Cookie.HttpOnly = true;

    options.Cookie.IsEssential = true;

    options.Cookie.SecurePolicy = CookieSecurePolicy.Always;

    options.IdleTimeout = TimeSpan.FromMinutes(30);

});



builder.Services.AddAuthentication(

    CookieAuthenticationDefaults.AuthenticationScheme)

    .AddCookie(options =>

    {

        options.Cookie.Name = "RaceDay.Auth";

        options.Cookie.HttpOnly = true;

        options.Cookie.SecurePolicy = CookieSecurePolicy.Always;

        options.Cookie.SameSite = SameSiteMode.Lax;

        options.ExpireTimeSpan = TimeSpan.FromMinutes(30);

        options.SlidingExpiration = true;



        // Return HTTP status codes instead of redirecting API clients.

        options.Events.OnRedirectToLogin = context =>

        {

            context.Response.StatusCode = 401;

            return Task.CompletedTask;

        };



        options.Events.OnRedirectToAccessDenied = context =>

        {

            context.Response.StatusCode = 403;

            return Task.CompletedTask;

        };

    });



builder.Services.AddAuthorization(options =>

{

    options.AddPolicy("OrganiserOnly", policy =>

        policy.RequireRole("Organiser"));



    options.AddPolicy("ParticipantOnly", policy =>

        policy.RequireRole("Participant"));

});



builder.Services.AddEndpointsApiExplorer();



builder.Services.AddSwaggerGen(options =>

{

    options.SwaggerDoc("v1", new OpenApiInfo

    {

        Title = "RaceDay API",

        Version = "v1",

        Description = "Event management API for South African road events."

    });

});



var app = builder.Build();



if (app.Environment.IsDevelopment())

{

    app.UseSwagger();

    app.UseSwaggerUI();

}



app.UseHttpsRedirection();

app.UseSession();

app.UseAuthentication();

app.UseAuthorization();



app.MapControllers();



app.Run();



// Makes the application accessible to WebApplicationFactory in tests.

public partial class Program;
public partial class program {}
