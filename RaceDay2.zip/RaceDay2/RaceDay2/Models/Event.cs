﻿using System.ComponentModel.DataAnnotations;



namespace RaceDay.Api.Models;



/// <summary>

/// Represents a running, walking or cycling event.

/// </summary>

public class Event

{

    public int EventId { get; set; }



    [Required, MaxLength(100)]

    public string Name { get; set; } = string.Empty;



    [MaxLength(1000)]

    public string Description { get; set; } = string.Empty;



    public DateTime Date { get; set; }



    [Required, MaxLength(150)]

    public string Location { get; set; } = string.Empty;



    public decimal DistanceKm { get; set; }



    [Required, MaxLength(10)]

    public string EventType { get; set; } = "Run";



    public int OrganizerId { get; set; }



    public User Organizer { get; set; } = null!;



    public ICollection<Category> Categories { get; set; }

        = new List<Category>();



    public ICollection<Enrollment> Enrollments { get; set; }

        = new List<Enrollment>();



    public ICollection<Performance> Performances { get; set; }

        = new List<Performance>();

}
