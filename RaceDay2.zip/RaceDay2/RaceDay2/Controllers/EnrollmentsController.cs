﻿using System.Security.Claims;

using Microsoft.AspNetCore.Authorization;

using Microsoft.AspNetCore.Mvc;

using Microsoft.EntityFrameworkCore;

using RaceDay.Api.Data;

using RaceDay.Api.DTOs;

using RaceDay.Api.Models;



namespace RaceDay.Api.Controllers;



/// <summary>

/// Manages participant enrolments in RaceDay events.

/// Participants can manage their own enrolments, while organisers

/// can view enrolments for events they organise.

/// </summary>

[ApiController]

[Route("api")]

[Authorize]

public class EnrollmentsController : ControllerBase

{

    private readonly RaceDayDbContext _db;



    /// <summary>

    /// Initialises the controller with the RaceDay database context.

    /// </summary>

    /// <param name="db">The database context.</param>

    public EnrollmentsController(RaceDayDbContext db)

    {

        _db = db;

    }



    /// <summary>

    /// Retrieves the enrolments belonging to the signed-in participant.

    /// </summary>

    /// <returns>The participant's enrolments.</returns>

    [HttpGet("enrollments/my")]

    [Authorize(Roles = "Participant")]

    public async Task<IActionResult> GetMyEnrollments()

    {

        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);



        if (!int.TryParse(userId, out var parsedUserId))

            return Unauthorized();



        var enrollments = await _db.Enrollments

            .Where(e => e.Participant.UserId == parsedUserId)

            .Select(e => new

            {

                e.EnrollmentId,

                e.EventId,

                EventName = e.Event.Name,

                e.ParticipantId,

                e.CategoryId,

                CategoryName = e.Category.Name,

                e.RegistrationDate,

                e.Status

            })

            .ToListAsync();



        return Ok(enrollments);

    }



    /// <summary>

    /// Retrieves one enrolment if the signed-in user is allowed to access it.

    /// </summary>

    /// <param name="id">The enrolment identifier.</param>

    /// <returns>The enrolment, or a not-found response.</returns>

    [HttpGet("enrollments/{id:int}")]

    public async Task<IActionResult> GetEnrollment(int id)

    {

        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);



        if (!int.TryParse(userId, out var parsedUserId))

            return Unauthorized();



        var enrollment = await _db.Enrollments

            .Where(e => e.EnrollmentId == id)

            .Where(e =>

                e.Participant.UserId == parsedUserId ||

                e.Event.OrganizerId == parsedUserId)

            .Select(e => new

            {

                e.EnrollmentId,

                e.EventId,

                EventName = e.Event.Name,

                e.ParticipantId,

                e.CategoryId,

                CategoryName = e.Category.Name,

                e.RegistrationDate,

                e.Status

            })

            .SingleOrDefaultAsync();



        if (enrollment == null)

            return NotFound();



        return Ok(enrollment);

    }



    /// <summary>

    /// Enrols the signed-in participant in an event category.

    /// </summary>

    /// <param name="dto">The event and category identifiers.</param>

    /// <returns>The newly created enrolment.</returns>

    [HttpPost("enrollments")]

    [Authorize(Roles = "Participant")]

    public async Task<IActionResult> CreateEnrollment(

        [FromBody] EnrollmentCreateDto dto)

    {

        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);



        if (!int.TryParse(userId, out var parsedUserId))

            return Unauthorized();



        var participant = await _db.Participants

            .SingleOrDefaultAsync(p => p.UserId == parsedUserId);



        if (participant == null)

            return BadRequest(

                "The signed-in user does not have a participant profile.");



        var category = await _db.Categories

            .SingleOrDefaultAsync(c =>

                c.CategoryId == dto.CategoryId &&

                c.EventId == dto.EventId);



        if (category == null)

            return BadRequest(

                "The selected category does not belong to this event.");



        var eventExists = await _db.Events

            .AnyAsync(e => e.EventId == dto.EventId);



        if (!eventExists)

            return NotFound("Event not found.");



        var alreadyEnrolled = await _db.Enrollments

            .AnyAsync(e =>

                e.EventId == dto.EventId &&

                e.ParticipantId == participant.ParticipantId);



        if (alreadyEnrolled)

            return Conflict(

                "You are already enrolled in this event.");



        var enrollment = new Enrollment

        {

            EventId = dto.EventId,

            ParticipantId = participant.ParticipantId,

            CategoryId = dto.CategoryId,

            RegistrationDate = DateTime.UtcNow,

            Status = "Registered"

        };



        _db.Enrollments.Add(enrollment);

        await _db.SaveChangesAsync();



        return CreatedAtAction(

            nameof(GetEnrollment),

            new { id = enrollment.EnrollmentId },

            new

            {

                enrollment.EnrollmentId,

                enrollment.EventId,

                enrollment.ParticipantId,

                enrollment.CategoryId,

                enrollment.RegistrationDate,

                enrollment.Status

            });

    }



    /// <summary>

    /// Cancels an enrolment owned by the signed-in participant.

    /// </summary>

    /// <param name="id">The enrolment identifier.</param>

    /// <returns>No content if the enrolment is deleted.</returns>

    [HttpDelete("enrollments/{id:int}")]

    [Authorize(Roles = "Participant")]

    public async Task<IActionResult> DeleteEnrollment(int id)

    {

        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);



        if (!int.TryParse(userId, out var parsedUserId))

            return Unauthorized();



        var enrollment = await _db.Enrollments

            .SingleOrDefaultAsync(e =>

                e.EnrollmentId == id &&

                e.Participant.UserId == parsedUserId);



        if (enrollment == null)

            return NotFound();



        _db.Enrollments.Remove(enrollment);

        await _db.SaveChangesAsync();



        return NoContent();

    }



    /// <summary>

    /// Retrieves enrolments for an event organised by the signed-in organiser.

    /// </summary>

    /// <param name="eventId">The event identifier.</param>

    /// <returns>The event's enrolments.</returns>

    [HttpGet("events/{eventId:int}/enrollments")]

    [Authorize(Roles = "Organiser")]

    public async Task<IActionResult> GetEventEnrollments(int eventId)

    {

        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);



        if (!int.TryParse(userId, out var parsedUserId))

            return Unauthorized();



        var eventExists = await _db.Events

            .AnyAsync(e =>

                e.EventId == eventId &&

                e.OrganizerId == parsedUserId);



        if (!eventExists)

            return NotFound("Event not found.");



        var enrollments = await _db.Enrollments

            .Where(e => e.EventId == eventId)

            .Select(e => new

            {

                e.EnrollmentId,

                e.EventId,

                e.ParticipantId,

                ParticipantName =

                    e.Participant.FirstName + " " +

                    e.Participant.LastName,

                e.CategoryId,

                CategoryName = e.Category.Name,

                e.RegistrationDate,

                e.Status

            })

            .ToListAsync();



        return Ok(enrollments);

    }

}


